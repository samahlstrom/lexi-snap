# Dict-to-Anki core modules
