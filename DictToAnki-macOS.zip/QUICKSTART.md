# Quick Start Guide

## Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

## Step 2: Install and Configure Anki

1. Download and install Anki from https://apps.ankiweb.net/
2. Open Anki
3. Install AnkiConnect add-on:
   - Tools → Add-ons → Get Add-ons
   - Enter code: **2055492159**
   - Click OK
4. **Restart Anki** (important!)
5. Keep Anki running in the background

## Step 3: Test the Installation

Run the test script to verify everything works:

```bash
python test_basic.py
```

You should see:
- ✓ Configuration PASS
- ✓ Dictionary API PASS
- ✓ AnkiConnect PASS (only if Anki is running)

## Step 4: Set Up System Integration

### Windows

Start the hotkey service:
```bash
python platform_integration/windows_menu.py --start
```

Now you can press **Ctrl+Alt+D** on any selected text to send to Anki!

**Optional:** To auto-start with Windows (requires administrator):
```bash
python platform_integration/windows_menu.py --install
```

### macOS

Follow the Automator setup:
```bash
python3 platform_integration/macos_service.py --show-instructions
```

## Step 5: Try It Out!

### Method 1: Command Line Test

```bash
python main.py --text "serendipity"
```

This will:
1. Look up "serendipity" in the dictionary
2. Show a deck selection dialog
3. Create an Anki card with definitions

### Method 2: Real-World Usage

1. Make sure Anki is running
2. Start the service (Windows): `python platform_integration/windows_menu.py --start`
3. Highlight a word (try: "ubiquitous" from any text)
4. Press **Ctrl+Alt+D** (Windows) or Services → "Send to Anki" (macOS)
5. Choose a deck
6. Check Anki to see your new card!

## Troubleshooting

### "Cannot connect to Anki"
- Make sure Anki is running
- Verify AnkiConnect is installed: Tools → Add-ons
- Restart Anki if you just installed AnkiConnect

### "No definitions found"
- Check your internet connection
- Try a common word like "example" or "test"

### Windows: Hotkey not working
- Check service status: `python platform_integration/windows_menu.py --status`
- Start the service: `python platform_integration/windows_menu.py --start`
- Restart the service: `python platform_integration/windows_menu.py --restart`

### macOS: Service not appearing
- Check System Settings → Keyboard → Keyboard Shortcuts → Services
- Make sure "Send to Anki" is enabled
- Grant Accessibility permissions if prompted

## What's Next?

- Read the full [README.md](README.md) for advanced features
- Configure settings in `%APPDATA%\dict-to-anki\config.ini` (Windows) or `~/.config/dict-to-anki/config.ini` (macOS)
- Try highlighting words while reading articles, PDFs, or browsing the web!

## Example Workflow

Let's say you're reading this sentence:

> "The ubiquitous smartphone has transformed modern communication."

1. Highlight "ubiquitous" (just the word)
2. Press **Ctrl+Alt+D** (Windows) or use Services menu (macOS)
3. Select your "English Vocabulary" deck
4. Done! A card is created with:
   - **Front**: ubiquitous
   - **Back**: 3 definitions with examples from the dictionary

Happy learning! 📚
